Sink the Itanic


A: This is hard
B: LostKng.enc is not part of the challenge, it's just a fun game included if you get frustrated


-soen
